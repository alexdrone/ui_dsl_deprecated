jlawton/UIColor-HTMLColors
tracy-e/ESCssParser
https://dribbble.com/BSteely 
https://github.com/steipete/RFLKAspects
facebook css-layout