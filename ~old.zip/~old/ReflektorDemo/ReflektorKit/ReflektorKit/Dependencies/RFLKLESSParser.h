//
// RFLKLESSParser.h
// Tests
// Forked from https://github.com/tracy-e/ESCssParser
//
//

#import <Foundation/Foundation.h>

@interface RFLKLESSParser : NSObject

- (NSDictionary*)parseText:(NSString *)RFLKLESSText;

@end